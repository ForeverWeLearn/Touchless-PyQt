from qdarktheme._os_appearance._accent import accent
