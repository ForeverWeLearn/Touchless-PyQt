"""Package including resources.

**Warning**

This package created programmatically. All changes made in this file will be lost!
Created by the `PyQtDarkTheme/tools/build_styles`.

"""

from qdarktheme._resources import colors, palette, stylesheets, svg

THEMES = ("dark", "light", "auto")
